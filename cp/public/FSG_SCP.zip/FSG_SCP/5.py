import sys
s=sys.argv[1]
print(s)
s=sys.argv[2]
print(s)